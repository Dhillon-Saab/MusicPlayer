Additional Components
	npm install @react-navigation/native
	npx expo install react-native-screens react-native-safe-area-context
	npm install @react-navigation/bottom-tabs
	npm install --save recyclerlistview
	npm install expo-av
	npm install @react-native-community/slider
	