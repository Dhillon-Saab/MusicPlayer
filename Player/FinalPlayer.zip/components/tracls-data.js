export const TRACKS = [
    {
      title: 'Believer',
      artist: 'Imagine Dragons',
      albumArtUrl: 'https://i.ytimg.com/vi/7wtfhZwyrcc/maxresdefault.jpg',
      audioUrl:
        'https://cdns-preview-d.dzcdn.net/stream/c-deda7fa9316d9e9e880d2c6207e92260-10.mp3',
    },
    {
      title: 'Senorita',
      artist: 'shawn mendes & camila cabello',
      albumArtUrl:
        'https://i1.sndcdn.com/artworks-000596770541-fw6dow-t500x500.jpg',
      audioUrl:
        'https://cdns-preview-d.dzcdn.net/stream/c-deda7fa9316d9e9e880d2c6207e92260-10.mp3',
    },
    {
      title: 'Brown Munde',
      artist: 'AP-DHILLON',
      albumArtUrl:
        'https://filmisongs.com/wp-content/uploads/2021/01/BROWN-MUNDE-Song-AP-DHILLON-X-GURINDER-GILL-Ft-SHINDA-KAHLON.jpg',
      audioUrl:
        'https://cdns-preview-d.dzcdn.net/stream/c-deda7fa9316d9e9e880d2c6207e92260-10.mp3',
    },
  ];