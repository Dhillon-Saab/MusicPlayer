This music player uses the following libraries that needs to be imported before running:

Defualt Libraries
	-npm install

Expo Media Library
	-npx expo install expo-media-library
React Navigation
	-npm install @react-navigation/native
	-npx expo install react-native-screens react-native-safe-area-context
	-npm install @react-navigation/bottom-tabs
