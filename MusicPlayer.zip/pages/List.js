import { Text, View , StyleSheet, ScrollView} from 'react-native'
import React, { Component } from 'react'
import { AudioContext } from './Permissions'

export class List extends Component {
static contextType = AudioContext
  render() {
    return (

        <ScrollView>
            {this.context.audioFiles.map(item=> <Text style={styles.audioItems} key={item.id}>{item.filename}</Text>)}
          
        </ScrollView>
      )
  }
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
    },
    audioItems:{
        padding: 10,
        borderBottomColor: 'black',
        borderBottomWidth: 2

    }
})
export default List