import { Text, View, Alert } from 'react-native'
import * as MediaLibrary from 'expo-media-library';
import React, {Component, createContext} from 'react';

export const AudioContext = createContext()

export class Permissions extends Component {
  constructor(props){
    super(props)
    this.state= {
        audioFiles: []
    }
  }

  permissionAlert = ()=>{
    Alert.alert("Permission Required", "This app requires the permission to read files in order to operate", 
    [{
        text: 'Continue',
        onPress: ()=> this.getPermission()
    },{
        text: 'Cancel',
        onPress: ()=>{
            this.permissionAlert();
        }
    }]);
  }

  getAudioFiles = async ()=>{
    let media = await MediaLibrary.getAssetsAsync({
        mediaType:'audio'
    })
    media = await MediaLibrary.getAssetsAsync({
        mediaType:'audio',
        first: media.totalCount,
    })
    console.log(media)

    this.setState({...this.state, audioFiles: media.assets})
  }

  getPermission = async () =>{
    // {"canAskAgain": true, "expires": "never", "granted": false, "status": "undetermined"}
    const permission = await MediaLibrary.getPermissionsAsync();

    if(permission.granted){
        this.getAudioFiles();
    }

    if(!permission.granted && permission.canAskAgain){
        const {status, canAskAgain} = await MediaLibrary.requestPermissionsAsync();
        
        if(status=== 'denied' && canAskAgain){
            this.permissionAlert();
        }
        if(status==='granted'){
            this.getAudioFiles();
        }
        if(status=== 'denied' && !canAskAgain){

        }
    }
  }

  componentDidMount(){
    this.getPermission();
  }
  
    render() {
    return (
        <AudioContext.Provider value={{audioFiles: this.state.audioFiles}}>
         {this.props.children}   
        </AudioContext.Provider>

    )
  }
}

export default Permissions